### Expected behaviour

I thought that by going to the page '...' and pressing the button '...' then '...' would happen.

### Actual behaviour

Instead of '...', what I saw was that '...' happened instead.

### Steps to reproduce

1. Go this JSFiddle, JSBin, CodePen, etc
2. Click on '....'
3. Scroll down to '....'
4. Refresh the page and wait 5 secs
5. Finally the error will magically happen (if it is raining)

### Browsers affected

I tested on all major browsers and only IE 11 does not work.
